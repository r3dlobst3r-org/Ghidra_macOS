This is where you put data files used by your contrib project.
